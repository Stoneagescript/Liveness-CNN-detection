import numpy as np
import argparse
import cv2
import os

#构造和解析参数
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--input", type=str, required=True,
	help="path to input video")
ap.add_argument("-o", "--output", type=str, required=True,
	help="path to output directory of cropped faces")
ap.add_argument("-d", "--detector", type=str, required=True,
	help="path to OpenCV's deep learning face detector")
#↑这个有现成的Caffemodel能用，就是res10_300x300_ssd_iter_140000.caffemodel
ap.add_argument("-c", "--confidence", type=float, default=0.5,
	help="minimum probability to filter weak detections")
#↑可以理解为置信度？不设置参数的情况下是小于50%的概率就判断不是人脸
ap.add_argument("-s", "--skip", type=int, default=16,
	help="# of frames to skip before applying face detection")
args = vars(ap.parse_args())
#↑假设一秒有n帧图像，但不全部捕获，这里采用了帧间跳过的算法，默认值为16，即在视频流中，每16帧才捕获一次图像
#从本地加载人脸检测器
print("[INFO] 加载人脸检测")
protoPath = os.path.sep.join([args["detector"], "deploy.prototxt"])
modelPath = os.path.sep.join([args["detector"],
	"res10_300x300_ssd_iter_140000.caffemodel"])
net = cv2.dnn.readNetFromCaffe(protoPath, modelPath)

#打开指向视频文件的指针
#读取和保存的帧数
vs = cv2.VideoCapture(args["input"])
read = 0
saved = 0

#循环处理帧
while True:
	#捕获帧
    (grabbed, frame) = vs.read()
	#没捕获到帧图像就结束力：（

	if not grabbed:
		break
	#读取的总帧数
	read += 1
	#检查args↑是否要处理该帧图像
	if read % args["skip"] != 0:
		continue

#从图像创建一个blob，有300x300的宽度和高度
	(h, w) = frame.shape[:2]
	blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0,
		(300, 300), (104.0, 177.0, 123.0))

	#很容易发现，我们的caffemodel也是300x300
	net.setInput(blob)
	detections = net.forward()

	if len(detections) > 0:
		#要确保每张图只有一个人脸
		i = np.argmax(detections[0, 0, :, 2])
		confidence = detections[0, 0, i, 2]
        #筛选弱检测导入

		if confidence > args["confidence"]:
			#计算感兴趣区域ROI和他的坐标
			box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
			(startX, startY, endX, endY) = box.astype("int")
			face = frame[startY:endY, startX:endX]

			#人脸导入磁盘
			p = os.path.sep.join([args["output"],
				"{}.png".format(saved)])
			cv2.imwrite(p, face)
			saved += 1
			print("[INFO] 保存 {} 到磁盘".format(p))
