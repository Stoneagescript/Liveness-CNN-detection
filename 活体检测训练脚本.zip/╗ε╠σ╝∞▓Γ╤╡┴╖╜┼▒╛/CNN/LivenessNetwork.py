from keras.models import Sequential
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.layers.core import Activation
from keras.layers.core import Flatten
from keras.layers.core import Dropout
from keras.layers.core import Dense
from keras import backend as K
#参考了一个简单CNN，减少了过滤器？的数量，让构建的网络保持在很浅的状态，减少计算的成本时间
class LivenessNet:
    @staticmethod
    def build(width, height, depth, classes):
        # 初始化模型

        model = Sequential()
        inputShape = (height, width, depth)
        chanDim = -1
        #使用channels first要更新输入
        if K.image_data_format() =="channels_first":
            inputShape = (depth, height, width)
            chandim = 1
 # first CONV => RELU => CONV => RELU => POOL layer set
        model.add(Conv2D(16, (3, 3), padding="same",
            input_shape = inputShape))
        model.add(Activation("relu"))
        model.add(BatchNormalization(axis=chanDim))
        model.add(Conv2D(16, (3, 3), padding="same"))
        model.add(Activation("relu"))
        model.add(BatchNormalization(axis=chanDim))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.25))
 # second CONV
        model.add(Conv2D(32, (3, 3), padding="same"))
        model.add(Activation("relu"))
        model.add(BatchNormalization(axis=chanDim))
        model.add(Conv2D(32, (3, 3), padding="same"))
        model.add(Activation("relu"))
        model.add(BatchNormalization(axis=chanDim))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.25))
        #FIRST SET  relu→一种斜坡函数，避免了梯度爆炸和梯度消失layer
        model.add(Flatten())
        model.add(Dense(64))
        model.add(Activation('relu'))
        model.add(BatchNormalization())
        model.add(Dropout(0.5))
        #softmax?log_softmax?,归一化指数函数
        model.add(Dense(classes))
        model.add(Activation("softmax"))
        #return网络架构↑应该是Keras的？
        return model
#此处构建完CNN后，需要


